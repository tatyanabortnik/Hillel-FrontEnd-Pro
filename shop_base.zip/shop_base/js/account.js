const orderTable = document.querySelector(`#orderTable`);
const userInfoName = document.querySelector(`#userInfoName`);
const userInfoEmail = document.querySelector(`#userInfoEmail`);
const deleteAcc = document.querySelector(`#deleteAcc`);

//renderAccountHtml//
const renderAccountHtml = () => {
   renderHeader();

   let loggedInUser = getLoggedinUser();
   userInfoName.innerHTML = loggedInUser.name;
   userInfoEmail.innerHTML = loggedInUser.email;

   deleteAcc.addEventListener(`click`, () => {
      confirm(`Are you sure you want to delete your account?`) &&
         logOut(loggedInUser);
   });
};
//renderAccountHtml//