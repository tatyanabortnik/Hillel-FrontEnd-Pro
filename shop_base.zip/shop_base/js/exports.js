import {getInfoUsers, getInfo,changeItem,deleteItem,addItem, APIusers, API} from './services.js';

export const loader = document.querySelector(`#loader`); // maybe need to put separately in index and shoppingcart

//addToCart//
export const addToCart = async (user, productId) => {
   user.shoppingCart.push({
      id: productId,
      count: 1,
   });

   let changedUser = await changeItem(`/${user.id}`, {
      shoppingCart: user.shoppingCart,
   });
   console.log(changedUser);

   localStorage.setItem(`loggedInUser`, JSON.stringify(user));

   getCartItemsQty(user);
};
//addToCart

//removeFromCart//
export const removeFromCart = async (user, productId) => {
   let itemIndex = user.shoppingCart.findIndex((item) => item.id == productId);
   user.shoppingCart.splice(itemIndex, 1);

   let changedUser = await changeItem(`/${user.id}`, {
      shoppingCart: user.shoppingCart,
   });
   console.log(changedUser);

   localStorage.setItem(`loggedInUser`, JSON.stringify(user));

   getCartItemsQty(user);
};
//removeFromCart

//getCartItemsQty
export const getCartItemsQty = (user, productID, inputEvent) => {
   if(inputEvent) {
      let user = getLoggedinUser();
      console.log(user)
      user.shoppingCart.forEach(item => item.id === productID ? item.count = inputEvent.target.value : null);
      console.log(user);
   }

   headerShoppingCartCount.innerHTML = user.shoppingCart.reduce(
      (prevItem, item) => prevItem + item.count,
      0
   );


};
//getCartItemsQty

//findDatabaseUser//
export const findDatabaseUser = async (form) => {
   const users = await getInfoUsers(APIusers);
   console.log(users);

   return users.find((item) => item.email === form.email);
};
//findDatabaseUser//

export const logOut = async (user) => {
   let changedUser = await changeItem(`/${user.id}`, { status: false });

   console.log(changedUser);

   localStorage.removeItem(`loggedInUser`);
   window.location.href = `./index.html`;
};

export const getLoggedinUser = () => {
   let loggedInUser = localStorage.getItem(`loggedInUser`); // null || {...}
   if (loggedInUser) {
      loggedInUser = JSON.parse(loggedInUser);
      return loggedInUser;
   }
};

export const showError = (event, text) => {
   const error = event.target.querySelector(`.error`);
   error.innerHTML = text;
   error.classList.add(`active`);
};

export const loginUser = async (user) => {
   let changedUser = await changeItem(`/${user.id}`, { status: true });
   console.log(changedUser);
   addToStorage(user);
   window.location.href = `./index.html`;
};

export const registerUser = async (user) => {
   user.status = true;
   console.log(user);

   let addedUser = await addItem(APIusers, user);
   console.log(addedUser);
   addToStorage(user);
   window.location.href = `./index.html`;
};

export const addToStorage = ({ id, name, email, shoppingCart, orders }) => {
   let loggedInUser = localStorage.getItem(`loggedInUser`);
   loggedInUser = loggedInUser
      ? JSON.parse(loggedInUser)
      : { id, name, email, shoppingCart, orders };
   console.log(email);
   localStorage.setItem(`loggedInUser`, JSON.stringify(loggedInUser));
};