import {getLoggedinUser,getCartItemsQty, logOut} from './exports.js'

export const headerShoppingCartCount = document.querySelector(`#headerShoppingCartCount`);
const headerShoppingCart = document.querySelector(`#headerShoppingCart`);
const headerLogout = document.querySelector(`#headerLogout`);
const headerUser = document.querySelector(`#headerUser`);

//renderHeader//
export const renderHeader = () => {
   let loggedInUser = getLoggedinUser();
   if (loggedInUser) {
      getCartItemsQty(loggedInUser);
      headerUser.innerHTML = loggedInUser.name;
      headerUser.href = `account.html`;
      headerLogout.classList.add(`active`);
      headerShoppingCart.href = `shoppingCart.html`
   } 

   headerLogout.addEventListener(`click`, () => logOut(getLoggedinUser()));
};
//renderHeader//