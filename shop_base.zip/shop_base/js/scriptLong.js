const API = `https://634e9f834af5fdff3a625f84.mockapi.io`;
const APIusers = `https://636fe0d34a801721e0fcaeac.mockapi.io/users`;

const categoriesContainer = document.querySelector(`#categoriesContainer`);
const headerShoppingCart = document.querySelector(`#headerShoppingCart`);
const headerShoppingCartCount = document.querySelector(
   `#headerShoppingCartCount`
);

const shoppingCartTable = document.querySelector(`#shoppingCartTable`);
const loginForm = document.querySelector(`#loginForm`);
const registrationForm = document.querySelector(`#registrationForm`);
const email = document.querySelector(`input[type="email"]`);
const password = document.querySelector(`input[type="password"]`);
const error = document.querySelectorAll(`.error`);

const headerLogout = document.querySelector(`#headerLogout`);
const headerUser = document.querySelector(`#headerUser`);

const orderTable = document.querySelector(`#orderTable`);
const userInfoName = document.querySelector(`#userInfoName`);
const userInfoEmail = document.querySelector(`#userInfoEmail`);
const deleteAcc = document.querySelector(`#deleteAcc`);

const orderSummary = document.querySelector(`#orderSummary`);
const loader = document.querySelector(`#loader`);

const getInfo = (path) => {
   loader.classList.add(`active`);

   return fetch(API + path)
      .then((data) => {
         loader.classList.remove(`active`);
         return data;
      })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));
};
const getInfoUsers = (path) => fetch(path).then((data) => data.json());

//service//
const changeItem = (itemPath, obj) =>
   fetch(APIusers + itemPath, {
      method: `PUT`,
      headers: {
         "Content-type": "application/json",
      },
      body: JSON.stringify(obj),
   })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));

const deleteItem = (itemPath) =>
   fetch(APIusers + itemPath, {
      method: `DELETE`,
   })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));

const addItem = (path, obj) =>
   fetch(path, {
      method: `POST`,
      headers: {
         "Content-type": "application/json",
      },
      body: JSON.stringify(obj),
   })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));
//service//


//renderIndexHtml//
const renderIndexHtml = async () => {
   renderHeader();

   let products = await getInfo(`/products`);
   // console.log(products);
   let loggedInUser = getLoggedinUser();

   let categories = [...new Set(products.map((product) => product.category))]; // unique categories
   // console.log(categories);

   categories.forEach((category) => {
      let section = document.createElement(`section`);
      section.className = "category";
      section.dataset.name = category;
      section.innerHTML = `<h2>${category}</h2>`;

      let categoryContainer = document.createElement(`div`);
      categoryContainer.className = "category__container";

      products.forEach(
         (product) =>
            product.category == category &&
            renderProduct(product, categoryContainer, loggedInUser)
      );

      section.append(categoryContainer);
      categoriesContainer.append(section);
   });
};
//renderIndexHtml//

//renderProduct//
const renderProduct = (product, place, user) => {
   let productDiv = document.createElement(`div`);
   productDiv.className = `product`;
   productDiv.dataset.id = product.id;

   let saleBlock = product.sale
      ? `<div class="product__sale">
                <span class="product__sale--old">${product.price}</span>
                <span class="product__sale--percent">-${product.salePercent}%</span>
            </div>`
      : ``;

   productDiv.innerHTML = `<img
                 src="images/products/${product.img}.png"
                 class="product__img"
                 alt="Bus"
                 height="80"
               />
               <p class="product__title">${product.title}</p>
               ${saleBlock}`;

   let infoDiv = document.createElement(`div`);
   infoDiv.className = `product__info`;
   infoDiv.innerHTML = `<span class="product__price">${
      product.sale
         ? product.price - product.salePercent / 100 * product.price
         : product.price
   }</span>`;

   let btn = document.createElement(`button`);
   btn.classList.add(`product__cart`);

   btn.innerHTML = `<img
                    src="images/shopping-cart.png"
                    alt="shopping cart"
                    height="20"/>`;

   if (user)
      user.shoppingCart.find((item) => item.id == product.id) &&
         btn.classList.add(`product__cart--in`);

   btn.addEventListener(`click`, (e) => {
      console.dir(e.currentTarget);
      if (user) {
         if (user.shoppingCart.some((item) => item.id == product.id)) {
            removeFromCart(user, product.id);
            e.currentTarget.classList.remove(`product__cart--in`);
         } else {
            addToCart(user, product.id);
            e.currentTarget.classList.add(`product__cart--in`);
         }
      } else {
         window.location.href = `./login.html`;
      }
   });

   infoDiv.append(btn);
   productDiv.append(infoDiv);
   place.append(productDiv);

   // console.dir(btn);
};
//renderProduct//

// const toggleItemInCart = await (user, productId) => { // index html red/green btn; change qty
//    let itemIndex = user.shoppingCart.findIndex(item => item.id === productId);

//    if(itemIndex !== -1) { //if exists
//       user.shoppingCart.splice(itemIndex, 1);

//       let changedUser = await changeItem(`/${user.id}`, {
//          shoppingCart: user.shoppingCart,
//       });
//       console.log(changedUser);

//       localStorage.setItem(`loggedInUser`, JSON.stringify(user));

//       getCartItemsQty(user);
//       } else {
//          user.shoppingCart.push({
//             id: productId,
//             count: 1,
//          });
      
//          let changedUser = await changeItem(`/${user.id}`, {
//             shoppingCart: user.shoppingCart,
//          });
//          console.log(changedUser);
      
//          localStorage.setItem(`loggedInUser`, JSON.stringify(user));
      
//          getCartItemsQty(user);
//    }
// }

//addToCart//
const addToCart = async () => {

   user.shoppingCart.push({
      id: productId,
      count: 1,
   });

   let changedUser = await changeItem(`/${user.id}`, {
      shoppingCart: user.shoppingCart,
   });
   console.log(changedUser);

   localStorage.setItem(`loggedInUser`, JSON.stringify(user));

   getCartItemsQty(user);
};
//addToCart

//removeFromCart//
const removeFromCart = async (user, productId) => {
   let itemIndex = user.shoppingCart.findIndex((item) => item.id == productId);
   user.shoppingCart.splice(itemIndex, 1);

   let changedUser = await changeItem(`/${user.id}`, {
      shoppingCart: user.shoppingCart,
   });
   console.log(changedUser);

   localStorage.setItem(`loggedInUser`, JSON.stringify(user));

   getCartItemsQty(user);
};
//removeFromCart

//getCartItemsQty
const getCartItemsQty = (user, productID, inputEvent) => {
   if(inputEvent) {
      let user = getLoggedinUser();
      console.log(user)
      user.shoppingCart.forEach(item => item.id === productID ? item.count = inputEvent.target.value : null);
      console.log(user);
   }

   headerShoppingCartCount.innerHTML = user.shoppingCart.reduce(
      (prevItem, item) => prevItem + item.count,
      0
   );


};
//getCartItemsQty

//renderAccountHtml//
const renderAccountHtml = () => {
   renderHeader();

   let loggedInUser = getLoggedinUser();
   userInfoName.innerHTML = loggedInUser.name;
   userInfoEmail.innerHTML = loggedInUser.email;

   deleteAcc.addEventListener(`click`, () => {
      confirm(`Are you sure you want to delete your account?`) &&
         logOut(loggedInUser);
   });
};
//renderAccountHtml//

//renderShoppingCartHtml//
const renderShoppingCartHtml = async () => {
   renderHeader();

   const products = await getInfo(`/products`);
   const loggedInUser = getLoggedinUser();
   const tbody = document.createElement(`tbody`);

   let match = products.filter((product) =>
      loggedInUser.shoppingCart.find(
         (userChoise) => userChoise.id === product.id
      )
   );

   console.log(match);

   match.forEach((i, index) => renderCartItem(i, tbody, loggedInUser));

   shoppingCartTable.append(tbody);
};
//renderShoppingCartHtml//

//renderCartItem//
const renderCartItem = (item, tbody, loggedInUser) => {
   const tr = document.createElement(`tr`);
   tr.innerHTML = `<td>
                   <div class="item__info">
                     <img
                      src="images/products/${item.img}.png"
                      alt="${item.title}"
                      height="100"
                    />
                    <div>
                      <p class="item__info--title">${item.title}</p>
                    </div>
                  </div>
                </td>
                <td>${item.price}</td>`;

   // item.sale ?
   // tr.innerHTML += `<td><span class="item__sale">

   tr.innerHTML += `<td>
         ${
            item.sale
               ? `<span class="item__sale">-${item.salePercent}%</span>`
               : `-`
         }
      </td>`
   
   const inputTd = document.createElement(`td`);
   const input = document.createElement(`input`);
   input.type = "number";
   // input.setAttribute(`value`,`1`);
      
   inputTd.append(input);
   tr.append(inputTd);
   
   console.dir(input);
   
   tr.innerHTML += `<td>$${item.sale 
      ? item.price - item.salePercent / 100 * item.price 
      : item.price
   }</td>`;
   
   const td = document.createElement(`td`);
   const btn = document.createElement(`button`);
   btn.classList.add = `item__remove`;
   btn.innerHTML = `<img src="images/delete.png" alt="delete" height="20" />`;
   
   td.append(btn);
   tr.append(td);
   tbody.append(tr);
   
   input.addEventListener(`input`, (e) => console.log(`input`));// getCartItemsQty(loggedInUser, item.id, e);)
   
   btn.addEventListener(`click`, () => {
      removeFromCart(loggedInUser,item.id);
      tr.remove();
   })

};
//renderCartItem//

//renderLoginHtml//
const renderLoginHtml = () => {
   renderHeader();

   loginForm.addEventListener(`submit`, async (e) => {
      e.preventDefault();

      const formData = Object.fromEntries(new FormData(e.target).entries());
      console.log(formData);

      const databaseUser = await findDatabaseUser(formData);
      console.log(databaseUser);

      if (databaseUser) {
         databaseUser.password == formData.password
            ? loginUser(databaseUser)
            : showError(e, `Invalid password`);
      } else showError(e, `Invalid email`);
   });

   registrationForm.addEventListener(`submit`, async (e) => {
      e.preventDefault();

      const formData = Object.fromEntries(new FormData(e.target).entries());
      console.log(formData);

      let databaseUser = await findDatabaseUser(formData);

      let newUser = {
         name: formData.name,
         email: formData.email,
         password: formData.password,
      };

      formData.password !== formData.passwordVerify &&
         showError(e, `Passwords don't match`);

      databaseUser
         ? showError(e, `User with email ${formData.email} already exist!`)
         : registerUser(newUser);
   });
};
//renderLoginHtml//

//findDatabaseUser//
const findDatabaseUser = async (form) => {
   const users = await getInfoUsers(APIusers);
   console.log(users);

   return users.find((item) => item.email === form.email);
};
//findDatabaseUser//

//renderHeader//
const renderHeader = () => {
   let loggedInUser = getLoggedinUser();
   getCartItemsQty(loggedInUser);
   if (loggedInUser) {
      headerUser.innerHTML = loggedInUser.name;
      headerUser.href = `account.html`;
      headerLogout.classList.add(`active`);
   } else {
      headerShoppingCart.href = `login.html`;
   }

   headerLogout.addEventListener(`click`, () => logOut(getLoggedinUser()));
};
//renderHeader//

const logOut = async (user) => {
   let changedUser = await changeItem(`/${user.id}`, { status: false });

   console.log(changedUser);

   localStorage.removeItem(`loggedInUser`);
   window.location.href = `./index.html`;
};

const getLoggedinUser = () => {
   let loggedInUser = localStorage.getItem(`loggedInUser`); // null || {...}
   if (loggedInUser) {
      loggedInUser = JSON.parse(loggedInUser);
      return loggedInUser;
   }
};

const showError = (event, text) => {
   const error = event.target.querySelector(`.error`);
   error.innerHTML = text;
   error.classList.add(`active`);
};

const loginUser = async (user) => {
   let changedUser = await changeItem(`/${user.id}`, { status: true });
   console.log(changedUser);
   addToStorage(user);
   window.location.href = `./index.html`;
};

const registerUser = async (user) => {
   user.status = true;
   console.log(user);

   let addedUser = await addItem(APIusers, user);
   console.log(addedUser);
   addToStorage(user);
   window.location.href = `./index.html`;
};

const addToStorage = ({ id, name, email, shoppingCart, orders }) => {
   let loggedInUser = localStorage.getItem(`loggedInUser`);
   loggedInUser = loggedInUser
      ? JSON.parse(loggedInUser)
      : { id, name, email, shoppingCart, orders };
   console.log(email);
   localStorage.setItem(`loggedInUser`, JSON.stringify(loggedInUser));
};

if (categoriesContainer) renderIndexHtml();
if (orderTable) renderAccountHtml();
if (orderSummary) renderShoppingCartHtml();
if (loginForm) renderLoginHtml();

//////////////////////////////////////////////////

const setAllFalse = async () => {
   const users = await getInfoUsers(APIusers);
   console.log(users);
   users.forEach(
      async (user) => await changeItem(`/${user.id}`, { status: false })
   );

   localStorage.removeItem(`loggedInUsers`);
};

// setAllFalse();

//with every change and logout save user data to server (shopping cart items...)
//change qty of items in shopping cart

//renderCartItem(item, index, tbody, loggedInUser); or
// renderCartItem( {item, index, tbody, loggedInUser} );

//чи можна переписати
// if (user) {
//    if (user.shoppingCart.some((item) => item.id == product.id)){
//       removeFromCart(e, user, product.id);
//       e.currentTarget.classList.remove(`product__cart--in`)
//    } else{
//       addToCart(e, user, product.id);
//       e.currentTarget.classList.add(`product__cart--in`)
//    }
// } else {
//    window.location.href = `./login.html`;
// }

//138.
// if (user)
// user.shoppingCart.find((item) => item.id == product.id) &&
// btn.classList.add(`product__cart--in`);

// addToCart - add to database not localstorage
