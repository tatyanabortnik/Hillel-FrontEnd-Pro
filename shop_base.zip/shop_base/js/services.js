export const API = `https://634e9f834af5fdff3a625f84.mockapi.io`;
export const APIusers = `https://636fe0d34a801721e0fcaeac.mockapi.io/users`;

export const getInfoUsers = (path) => fetch(path).then((data) => data.json());

//service//
export const getInfo = (path) => {
   loader.classList.add(`active`);

   return fetch(API + path)
      .then((data) => {
         loader.classList.remove(`active`);
         return data;
      })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));
};

export const changeItem = (itemPath, obj) =>
   fetch(APIusers + itemPath, {
      method: `PUT`,
      headers: {
         "Content-type": "application/json",
      },
      body: JSON.stringify(obj),
   })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));

export const deleteItem = (itemPath) =>
   fetch(APIusers + itemPath, {
      method: `DELETE`,
   })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));

export const addItem = (path, obj) =>
   fetch(path, {
      method: `POST`,
      headers: {
         "Content-type": "application/json",
      },
      body: JSON.stringify(obj),
   })
      .then((data) => data.json())
      .catch((err) => console.log(`error:`, err));
//service//