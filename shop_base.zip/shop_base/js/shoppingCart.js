import { getInfo } from './services.js';
import { getLoggedinUser, removeFromCart } from './exports.js';
import { renderHeader } from './header.js';


const shoppingCartTable = document.querySelector(`#shoppingCartTable`);
const orderSummary = document.querySelector(`#orderSummary`);
const orderSummaryTotal = document.querySelector(`#orderSummaryTotal`);

//renderShoppingCartHtml//
const renderShoppingCartHtml = async () => {
   renderHeader();

   const products = await getInfo(`/products`);
   const loggedInUser = getLoggedinUser();
   const tbody = document.createElement(`tbody`);

   let orderedProductsInfo = products.filter((product) =>
      loggedInUser.shoppingCart.find(
         (userChoise) => userChoise.id === product.id
      )
   );

   console.log(orderedProductsInfo);

   orderedProductsInfo.forEach((i, index) => renderCartItem(i, tbody, loggedInUser));

   shoppingCartTable.append(tbody);
};
//renderShoppingCartHtml//

//renderCartItem//
const renderCartItem = (item, tbody, loggedInUser) => {
   let orderedItemQty = loggedInUser.shoppingCart.find(product => product.id == item.id).count;

   const tr = document.createElement(`tr`);
   tr.innerHTML = `<td>
                   <div class="item__info">
                     <img
                      src="images/products/${item.img}.png"
                      alt="${item.title}"
                      height="100"
                    />
                    <div>
                      <p class="item__info--title">${item.title}</p>
                    </div>
                  </div>
                </td>
                <td>${item.price}</td>`;

   tr.innerHTML += `<td>
         ${
            item.sale
               ? `<span class="item__sale">-${item.salePercent}%</span>`
               : `-`
         }
      </td>`

   const qtyTd = document.createElement(`td`);
   const qtyInput = document.createElement(`input`);
   
   qtyInput.setAttribute('type', 'number');
   // qtyInput.setAttribute('value', 1);
   // qtyInput.setAttribute('type', 'number'); 
   qtyInput.value = "1";

   qtyInput.setAttribute('min','1');

   qtyTd.append(qtyInput);
   tr.append(qtyTd);
   
   console.dir(qtyInput);

   let itemPrice = item.sale 
      ? item.price - item.salePercent / 100 * item.price 
      : item.price;

   tr.innerHTML += `<td>$${itemPrice}</td>`;
   
   const td = document.createElement(`td`);
   const btn = document.createElement(`button`);
   btn.classList.add = `item__remove`;
   btn.innerHTML = `<img src="images/delete.png" alt="delete" height="20" />`;
   
   td.append(btn);
   tr.append(td);
   tbody.append(tr);

   changeOrderTotal(itemPrice);

   qtyInput.addEventListener(`input`, (e) => {
      console.log(e.target.value);
      // changeOrderTotal(itemPrice, e.target.value);
      // getCartItemsQty(loggedInUser, item.id, e);)
   })
   
   btn.addEventListener(`click`, () => {
      removeFromCart(loggedInUser,item.id);
      tr.remove();
   })

};
//renderCartItem//

const changeOrderTotal = (itemPrice, qty = 1) => {
   let sum = orderSummaryTotal.innerHTML.split(``);
   sum.shift();
   sum = + sum.join(``);

   console.log(sum);
   sum += itemPrice * qty;
   orderSummaryTotal.innerHTML = `$${sum}`;
}

renderShoppingCartHtml();